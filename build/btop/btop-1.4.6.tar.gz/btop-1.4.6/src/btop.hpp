#include <span>
#include <string_view>

[[nodiscard]] auto btop_main(std::span<const std::string_view> args) -> int;
